var s;const t=((s=globalThis.__sveltekit_1vwe6l1)==null?void 0:s.base)??"/Portfolio-Website";var e;const a=((e=globalThis.__sveltekit_1vwe6l1)==null?void 0:e.assets)??t;export{a,t as b};
