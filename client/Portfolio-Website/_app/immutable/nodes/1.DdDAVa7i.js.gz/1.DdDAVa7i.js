import{t,a}from"../chunks/CFku7UP8.js";import"../chunks/B2DgBvSz.js";var e=t('<div id="page-content"><p>An Error had been found.</p></div>');function d(o){var r=e();a(o,r)}export{d as component};
