import{t as l,a as m}from"../chunks/CFku7UP8.js";import"../chunks/B2DgBvSz.js";import{B as p,$ as h,C as c,F as o,G as i,Q as g}from"../chunks/DgWED3Zr.js";import{b}from"../chunks/6O37bfvL.js";import{s as y}from"../chunks/pVwa9F55.js";import{b as s}from"../chunks/Bu00k6R7.js";import{H as v}from"../chunks/BV-9vh2Q.js";var u=l(`<!> <div id="page-content"><div class="aboutImg"><img alt="Kacie" width="470px"></div> <div class="headerText"><h1>About Me</h1> <br></div> <div class="paragraphText"><p>Hi! My name is Kacie Franklin.
       I'm currently a student at South East Technological College, Carlow, in Ireland.
       The course I'm studying is Interactive Digital Art in Media and Design,
       a course that focuses on digital art and website design and programming.
       Art is a huge passion of mine always has been and I only aim to improve as time goes by.
       A lot of my art is original characters I made and hold fondly to my heart which I plan to eventually tell their stories in one way or another.
       During my primary and secondry school years I learned to speak Irish and can speak it fluently.
       I don't know what else to say about myself so I'll leave it here for now.</p> <br> <p>Thank you for stopping by my website and having a look, hope you have a good day!</p></div> <br><br><br><br><br><br><br><br><br></div>`,1);function T(n){var a=u();b(f=>{h.title="About Me"});var e=p(a);v(e,{rectangle:`${s??""}/HeaderImg.png`,title:"AboutMe"});var t=c(e,2),r=o(t),d=o(r);y(d,"src",`${s??""}/Kacie.jpeg`),i(r),g(14),i(t),m(n,a)}export{T as component};
